import { createContext } from "react";

const audioEngineContext = createContext([]);

export default audioEngineContext;