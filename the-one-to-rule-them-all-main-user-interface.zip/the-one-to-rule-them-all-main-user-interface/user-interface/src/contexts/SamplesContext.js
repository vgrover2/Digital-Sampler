import { createContext } from "react";

const SamplesContext = createContext();
export default SamplesContext;