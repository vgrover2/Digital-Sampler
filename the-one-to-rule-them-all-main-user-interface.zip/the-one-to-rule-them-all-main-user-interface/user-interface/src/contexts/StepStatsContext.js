import { createContext } from "react";

const stepStatsContext = createContext();

export default stepStatsContext;