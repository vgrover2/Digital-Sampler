import { createContext } from "react";

const SelectedSampleContext = createContext();

export default SelectedSampleContext;