import { createContext } from "react";

const usernameContext = createContext("");

export default usernameContext;