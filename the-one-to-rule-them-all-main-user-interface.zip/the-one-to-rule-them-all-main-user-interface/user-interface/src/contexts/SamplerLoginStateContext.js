import { createContext } from "react";

const loginStateContext = createContext(0);

export default loginStateContext;