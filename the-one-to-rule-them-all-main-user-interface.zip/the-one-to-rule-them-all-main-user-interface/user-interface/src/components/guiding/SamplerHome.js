import "./style.css"

export default function SamplerHome () {
    return (

        <div className="main">
            <img src={require("../../img/HomePage.jpg")} alt="oops"/>
        </div>    
    )
}